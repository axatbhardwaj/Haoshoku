-- Change the default Omarchy look'n'feel.

-- https://wiki.hypr.land/Configuring/Basics/Variables/#general
-- hl.config({
--   general = {
--     -- No gaps between windows or borders.
--     gaps_in = 0,
--     gaps_out = 0,
--     border_size = 0,
--
--     -- Change to niri-like side-scrolling layout.
--     layout = "scrolling",
--   },
-- })

-- https://wiki.hypr.land/Configuring/Basics/Variables/#decoration
-- hl.config({
--   decoration = {
--     -- Use round window corners.
--     rounding = 8,
--
--     -- Dim unfocused windows (0.0 = no dim, 1.0 = fully dimmed).
--     dim_inactive = true,
--     dim_strength = 0.15,
--   },
-- })

-- https://wiki.hypr.land/Configuring/Basics/Variables/#animations
-- hl.config({
--   animations = {
--     -- Disable all animations.
--     enabled = false,
--   },
-- })

-- https://wiki.hypr.land/Configuring/Basics/Variables/#layout
-- hl.config({
--   layout = {
--     -- Avoid overly wide single-window layouts on wide screens.
--     single_window_aspect_ratio = { 1, 1 },
--   },
-- })

-- https://wiki.hypr.land/Configuring/Layouts/Scrolling-Layout/
-- hl.config({
--   scrolling = {
--     -- See only one column per screen instead of two.
--     column_width = 0.97,
--   },
-- })

-- Restore window blur. Omarchy 4 ships blur disabled by default; Elysian's
-- hyprland.conf glass block is not loaded (cloned themes only contribute
-- generated hyprland.lua). `special = true` also blurs special workspaces.
-- Size 24 is 2x the last visibly-working radius (12). Passes stay at 4:
-- Dual Kawase downsamples each pass, so 8 passes flattened the wallpaper
-- into a solid color and looked like blur was off.
hl.config({
  decoration = {
    blur = {
      enabled = true,
      size = 24,
      passes = 4,
      special = true,
      xray = true,
      noise = 0.03,
      contrast = 1.45,
      brightness = 1.15,
      vibrancy = 0.03,
      vibrancy_darkness = 0.7,
    },
  },
})

-- Opt apps into glass explicitly: Omarchy no longer assigns default-opacity.
-- Later rules retain readable browsers and opaque terminal/credential windows.
o.transparent_window(".*", "0.80 override 0.80 override")
o.window({ tag = "chromium-based-browser" }, { opacity = "0.90 override 0.90 override" })
o.window({ tag = "firefox-based-browser" }, { opacity = "0.90 override 0.90 override" })
o.window("chromium-[a-z0-9-]+", { opacity = "0.90 override 0.90 override" })
o.window("chrome-.*__-Default", { opacity = "0.90 override 0.90 override" })
o.window("brave-.*", { opacity = "0.90 override 0.90 override" })
o.window({ tag = "terminal" }, { opacity = "1 override 1 override" })
o.window(
  "^(haoshoku-ws7|haoshoku-haki|haoshoku-agents|com\\.haoshoku\\.ws7)$",
  { opacity = "1 override 1 override" }
)
o.window(
  "(1[pP]assword|Bitwarden|org\\.keepassxc\\.KeePassXC|Proton Pass)",
  { opacity = "1 override 1 override" }
)
o.window({ tag = "pip" }, { opacity = "1 override 1 override" })
o.window({ title = "WebcamOverlay" }, { opacity = "1 override 1 override" })
o.window("dev\\.zed\\.Zed", { opacity = "1 override 1 override" })
o.window(
  "^(brave-youtube\\.com__-Default|brave-www\\.crunchyroll\\.com__-Default|brave-www\\.jiohotstar\\.com__-Default|brave-reanime\\.to__home-Default)$",
  { opacity = "1 override 1 override" }
)

-- GTK 4.24 (Ghostty, Nautilus) advertises ext-background-effect, which makes
-- Hyprland 0.56 skip window blur entirely (sharp wallpaper behind glass).
-- Hide the protocol from GTK until upstream fixes it:
-- https://github.com/omacom/omarchy/issues/15793
-- https://github.com/hyprwm/Hyprland/issues/16508
hl.env("GDK_WAYLAND_DISABLE", "ext_background_effect_manager_v1")

-- Opt another application in to Omarchy's standard transparency.
-- Find its class with: hyprctl clients
-- o.transparent_window("my-app")
-- o.transparent_window("my-app", "0.9 0.85") -- Custom active/inactive opacity.
